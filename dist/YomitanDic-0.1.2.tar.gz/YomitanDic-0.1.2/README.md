"# yomitan-dic" 
